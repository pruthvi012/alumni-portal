// Initial Data Setup
const initialAlumni = [
    { name: "Priya Sharma", email: "priya@example.com", year: 2020, industry: "Information Technology", skills: "Java, Spring Boot, MySQL" },
    { name: "Arjun Mehta", email: "arjun@example.com", year: 2019, industry: "Finance", skills: "Python, Risk Analysis, Excel" },
    { name: "Sneha Rao", email: "sneha@example.com", year: 2021, industry: "Healthcare", skills: "Data Analysis, R" }
];

const initialJobs = [
    { title: "Java Developer", company: "TechCorp", industry: "IT", location: "Bangalore", desc: "Build amazing APIs" },
    { title: "Financial Analyst", company: "HDFC", industry: "Finance", location: "Mumbai", desc: "Equity analysis" }
];

const initialMentors = [
    { name: "Karthik Nair", industry: "IT", expertise: "Cloud, AWS, DevOps" },
    { name: "Divya Pillai", industry: "Marketing", expertise: "SEO, Google Ads" }
];

// Load from LocalStorage or use Initial Data
let alumni = JSON.parse(localStorage.getItem('alumni')) || initialAlumni;
let jobs = JSON.parse(localStorage.getItem('jobs')) || initialJobs;
let mentors = JSON.parse(localStorage.getItem('mentors')) || initialMentors;

let currentSection = 'alumni';

function showSection(section) {
    currentSection = section;
    const grid = document.getElementById('content-grid');
    const title = document.getElementById('section-title');
    grid.innerHTML = '';
    
    document.querySelectorAll('nav li').forEach(li => li.classList.remove('active'));
    const activeLi = document.querySelector(`li[onclick*="${section}"]`);
    if (activeLi) activeLi.classList.add('active');

    if (section === 'alumni') {
        title.innerText = 'Alumni Directory';
        alumni.forEach(person => {
            grid.innerHTML += createCard(person.name, person.industry, `Class of ${person.year} • ${person.email}`, person.skills);
        });
    } else if (section === 'jobs') {
        title.innerText = 'Job Opportunities';
        jobs.forEach(job => {
            grid.innerHTML += createCard(job.title, job.industry, `${job.company} • ${job.location}`, job.desc);
        });
    } else if (section === 'mentors') {
        title.innerText = 'Mentorship Hub';
        mentors.forEach(m => {
            grid.innerHTML += createCard(m.name, m.industry, "Available for mentoring", m.expertise);
        });
    }
}

function createCard(title, tag, info, subtext) {
    return `
        <div class="card">
            <h3>${title}</h3>
            <div class="info">${info}</div>
            <p style="margin-top: 10px; font-size: 0.85rem; color: var(--text-dim)">${subtext}</p>
            <div class="tag">${tag}</div>
        </div>
    `;
}

function handleSearch() {
    const query = document.getElementById('search-input').value.toLowerCase();
    document.querySelectorAll('.card').forEach(card => {
        card.style.display = card.innerText.toLowerCase().includes(query) ? 'block' : 'none';
    });
}

function openModal() {
    document.getElementById('modal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

function saveData() {
    const name = document.getElementById('form-name').value;
    const email = document.getElementById('form-email').value;
    const industry = document.getElementById('form-industry').value;

    if (!name || !email) return alert("Please fill in Name and Email");

    if (currentSection === 'alumni') {
        alumni.push({ name, email, year: 2024, industry, skills: "New Member" });
        localStorage.setItem('alumni', JSON.stringify(alumni));
    }
    
    closeModal();
    showSection(currentSection);
}

window.onload = () => showSection('alumni');

